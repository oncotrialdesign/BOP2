#' Maximum response boundary for a posterior-probability cutoff
#'
#' Calculates the largest number of observed responses at which the trial would
#' stop for futility under the binary BOP2 monitoring rule. The original source
#' code used the posterior promising probability, Pr(p > phi | data), and stops
#' when that probability is below the cutoff.
#'
#' @param cutoff Posterior promising-probability cutoff. In the source code this
#'   is lambda * (n / nmax)^alpha.
#' @param dprior Numeric vector of Dirichlet or beta prior parameters. For a
#'   binary endpoint, use c(a_response, a_no_response).
#' @param ntr Current sample size.
#' @param phi Null response-rate threshold used in Pr(p > phi | data).
#' @param contrast 0/1 matrix indicating which endpoint categories compose the
#'   event of interest. For a binary response endpoint, use as.matrix(1).
#'
#' @return Integer vector. For the binary endpoint case, the value is the rule
#'   "stop if the number of responses is less than or equal to this value".
#' @export
#'
#' @examples
#' maxresp(cutoff = 0.85, dprior = c(0.15, 0.85), ntr = 20,
#'         phi = 0.15, contrast = as.matrix(1))
maxresp <- function(cutoff, dprior, ntr, phi, contrast = as.matrix(1)) {
  dprior <- validate_prior(dprior)
  contrast <- as_contrast_matrix(contrast)

  if (!is.numeric(ntr) || length(ntr) != 1L || is.na(ntr) || ntr <= 0 || ntr != floor(ntr)) {
    stop("ntr must be a positive integer sample size.", call. = FALSE)
  }
  ntr <- as.integer(ntr)

  if (!is.numeric(phi) || length(phi) != nrow(contrast) || any(is.na(phi))) {
    stop("phi must be numeric and have one value for each row of contrast.", call. = FALSE)
  }
  if (length(cutoff) == 1L) {
    cutoff <- rep(cutoff, nrow(contrast))
  }
  if (!is.numeric(cutoff) || length(cutoff) != nrow(contrast) || any(is.na(cutoff)) ||
      any(cutoff < 0) || any(cutoff > 1)) {
    stop("cutoff must be between 0 and 1 and have length 1 or one value per contrast row.", call. = FALSE)
  }
  if (ncol(contrast) > length(dprior)) {
    stop("contrast has more columns than dprior has categories.", call. = FALSE)
  }

  ncut <- integer(nrow(contrast))
  response_counts <- 0:ntr

  for (i in seq_len(nrow(contrast))) {
    event_index <- which(contrast[i, ] == 1)
    a_event_prior <- sum(dprior[event_index])
    a_non_event_prior <- sum(dprior) - a_event_prior

    posterior_promising <- 1 - stats::pbeta(
      phi[i],
      response_counts + a_event_prior,
      ntr - response_counts + a_non_event_prior
    )

    candidates <- which(posterior_promising < cutoff[i])
    ncut[i] <- if (length(candidates) == 0L) -1L else max(candidates) - 1L
  }

  names(ncut) <- paste0("criterion", seq_along(ncut))
  ncut
}

#' Binary BOP2 stopping boundaries
#'
#' Creates the binary endpoint futility stopping boundary at each interim/final
#' look. The boundary is interpreted as: stop for futility if the cumulative
#' number of responses is less than or equal to the listed value.
#'
#' @param nobs Increasing vector of interim and final sample sizes.
#' @param lambda Tuning parameter lambda in lambda * (n / N)^alpha.
#' @param alpha Tuning parameter alpha in lambda * (n / N)^alpha.
#' @param p_null Null response-rate threshold.
#' @param dprior Beta prior parameters. Defaults to c(p_null, 1 - p_null), which
#'   matches the attached source-code convention.
#' @param phi Response-rate threshold for posterior monitoring. Defaults to
#'   p_null.
#' @param contrast Contrast matrix. For the binary setting, use as.matrix(1).
#'
#' @return A data frame with look number, sample size, posterior cutoff, and
#'   response-count stopping boundary.
#' @export
#'
#' @examples
#' stopping_boundary_binary(nobs = c(20, 40), lambda = 0.8, alpha = 0.5,
#'                          p_null = 0.15)
stopping_boundary_binary <- function(nobs, lambda, alpha, p_null,
                                     dprior = c(p_null, 1 - p_null),
                                     phi = p_null,
                                     contrast = as.matrix(1)) {
  nobs <- validate_nobs(nobs)
  validate_probability(lambda, "lambda")
  if (!is.numeric(alpha) || length(alpha) != 1L || is.na(alpha) || alpha < 0) {
    stop("alpha must be a single non-negative numeric value.", call. = FALSE)
  }
  validate_strict_probability(p_null, "p_null")
  validate_prior(dprior)

  nmax <- max(nobs)
  cutoffs <- lambda * (nobs / nmax)^alpha
  boundaries <- vapply(
    seq_along(nobs),
    function(i) maxresp(
      cutoff = cutoffs[i],
      dprior = dprior,
      ntr = nobs[i],
      phi = phi,
      contrast = contrast
    )[1],
    integer(1L)
  )

  data.frame(
    look = seq_along(nobs),
    n = nobs,
    posterior_promising_cutoff = cutoffs,
    stop_if_responses_leq = as.integer(boundaries),
    row.names = NULL
  )
}

#' Search for an optimized binary BOP2 design
#'
#' Performs a grid search over lambda and alpha. Candidate designs whose
#' simulated type I error is no greater than the target are retained, and the
#' retained design with the largest simulated power is selected.
#'
#' @param nobs Increasing vector of interim and final sample sizes.
#' @param p_null Null response probability.
#' @param p_alt Alternative response probability.
#' @param target_type1 One-sided type I error target.
#' @param nsim Number of simulated trials per scenario.
#' @param lambda_grid Numeric grid for lambda.
#' @param alpha_grid Numeric grid for alpha.
#' @param dprior Beta prior parameters. Defaults to c(p_null, 1 - p_null).
#' @param seed Optional random seed. The same seed is used across candidates for
#'   the null scenario and seed + 1 is used for the alternative scenario.
#' @param verbose Logical indicator for progress messages.
#'
#' @return An object of class bop2_binary_design containing the selected lambda,
#'   alpha, simulated operating characteristics, all retained grid-search
#'   results, and the stopping boundary.
#' @export
#'
#' @examples
#' design <- search_binary_design(
#'   nobs = c(20, 40), p_null = 0.15, p_alt = 0.30,
#'   target_type1 = 0.10, nsim = 1000,
#'   lambda_grid = seq(0.70, 0.90, by = 0.05),
#'   alpha_grid = seq(0, 1, by = 0.25)
#' )
#' design
#' design$boundary
search_binary_design <- function(nobs, p_null, p_alt, target_type1 = 0.10,
                                 nsim = 10000,
                                 lambda_grid = seq(0.70, 0.90, by = 0.01),
                                 alpha_grid = seq(0, 1, by = 0.01),
                                 dprior = c(p_null, 1 - p_null),
                                 seed = 1024, verbose = FALSE) {
  nobs <- validate_nobs(nobs)
  validate_strict_probability(p_null, "p_null")
  validate_probability(p_alt, "p_alt")
  validate_probability(target_type1, "target_type1")
  validate_prior(dprior)
  if (!is.numeric(nsim) || length(nsim) != 1L || is.na(nsim) || nsim <= 0 || nsim != floor(nsim)) {
    stop("nsim must be a positive integer.", call. = FALSE)
  }
  if (!is.numeric(lambda_grid) || length(lambda_grid) < 1L || any(is.na(lambda_grid)) ||
      any(lambda_grid < 0) || any(lambda_grid > 1)) {
    stop("lambda_grid must contain values between 0 and 1.", call. = FALSE)
  }
  if (!is.numeric(alpha_grid) || length(alpha_grid) < 1L || any(is.na(alpha_grid)) ||
      any(alpha_grid < 0)) {
    stop("alpha_grid must contain non-negative values.", call. = FALSE)
  }

  alt_seed <- if (is.null(seed)) NULL else seed + 1L
  rows <- vector("list", length(lambda_grid) * length(alpha_grid))
  idx <- 0L

  for (lambda in lambda_grid) {
    for (alpha in alpha_grid) {
      oc_null <- get_oc_binary(
        nsim = nsim,
        nobs = nobs,
        ptrue = p_null,
        p_null = p_null,
        lambda = lambda,
        alpha = alpha,
        dprior = dprior,
        seed = seed
      )
      type1 <- oc_null$new_accept

      if (type1 <= target_type1) {
        oc_alt <- get_oc_binary(
          nsim = nsim,
          nobs = nobs,
          ptrue = p_alt,
          p_null = p_null,
          lambda = lambda,
          alpha = alpha,
          dprior = dprior,
          seed = alt_seed
        )
        idx <- idx + 1L
        rows[[idx]] <- data.frame(
          lambda = lambda,
          alpha = alpha,
          type1_error = type1,
          power = oc_alt$new_accept,
          pet_null = oc_null$earlystop,
          pet_alt = oc_alt$earlystop,
          mean_n_null = oc_null$meanpts,
          mean_n_alt = oc_alt$meanpts
        )
      } else if (isTRUE(verbose)) {
        message("Skipping lambda = ", lambda, ", alpha = ", alpha,
                ": type I error = ", round(type1, 4))
      }
    }
  }

  if (idx == 0L) {
    stop("No grid-search candidate satisfied the target_type1 constraint. Try expanding the grid or increasing the sample size.", call. = FALSE)
  }

  grid_results <- do.call(rbind, rows[seq_len(idx)])
  best_index <- which.max(grid_results$power)
  best <- grid_results[best_index, , drop = FALSE]
  boundary <- stopping_boundary_binary(
    nobs = nobs,
    lambda = best$lambda,
    alpha = best$alpha,
    p_null = p_null,
    dprior = dprior
  )

  structure(
    list(
      lambda = best$lambda,
      alpha = best$alpha,
      p_null = p_null,
      p_alt = p_alt,
      target_type1 = target_type1,
      nsim = as.integer(nsim),
      best = best,
      boundary = boundary,
      grid_results = grid_results,
      call = match.call()
    ),
    class = "bop2_binary_design"
  )
}

#' @export
print.bop2_binary_design <- function(x, ...) {
  cat("BOP2 binary phase II design\n")
  cat("  Null response rate:        ", x$p_null, "\n", sep = "")
  cat("  Alternative response rate: ", x$p_alt, "\n", sep = "")
  cat("  Target type I error:       ", x$target_type1, "\n", sep = "")
  cat("  Simulations per scenario:  ", x$nsim, "\n\n", sep = "")
  cat("Selected tuning parameters and operating characteristics:\n")
  print(x$best, row.names = FALSE)
  cat("\nStopping boundary:\n")
  print(x$boundary, row.names = FALSE)
  cat("\nRule: stop for futility if cumulative responses <= stop_if_responses_leq.\n")
  invisible(x)
}

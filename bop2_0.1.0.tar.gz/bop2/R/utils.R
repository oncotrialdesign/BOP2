validate_probability <- function(x, name) {
  if (!is.numeric(x) || length(x) != 1L || is.na(x) || x < 0 || x > 1) {
    stop(name, " must be a single numeric value between 0 and 1.", call. = FALSE)
  }
  invisible(TRUE)
}

validate_strict_probability <- function(x, name) {
  validate_probability(x, name)
  if (x <= 0 || x >= 1) {
    stop(name, " must be strictly between 0 and 1 for the beta prior.", call. = FALSE)
  }
  invisible(TRUE)
}

validate_nobs <- function(nobs) {
  if (!is.numeric(nobs) || length(nobs) < 1L || any(is.na(nobs))) {
    stop("nobs must be a numeric vector of interim and final sample sizes.", call. = FALSE)
  }
  if (any(nobs <= 0) || any(nobs != floor(nobs))) {
    stop("nobs must contain positive integer sample sizes.", call. = FALSE)
  }
  if (length(nobs) > 1L && any(diff(nobs) <= 0)) {
    stop("nobs must be strictly increasing.", call. = FALSE)
  }
  as.integer(nobs)
}

validate_prior <- function(dprior) {
  if (!is.numeric(dprior) || length(dprior) < 2L || any(is.na(dprior)) || any(dprior <= 0)) {
    stop("dprior must be a positive numeric vector with at least two components.", call. = FALSE)
  }
  dprior
}

as_contrast_matrix <- function(contrast) {
  if (is.null(contrast)) {
    contrast <- as.matrix(1)
  }
  if (is.null(dim(contrast))) {
    contrast <- matrix(contrast, nrow = 1L)
  } else {
    contrast <- as.matrix(contrast)
  }
  if (!all(contrast %in% c(0, 1))) {
    stop("contrast must contain only 0/1 indicators.", call. = FALSE)
  }
  contrast
}

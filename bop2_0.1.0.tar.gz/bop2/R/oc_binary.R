#' Operating characteristics for a binary BOP2 design
#'
#' Simulates the operating characteristics for the binary endpoint BOP2 design.
#' The treatment is declared promising only when the final cumulative number of
#' responses exceeds the final stopping boundary and no interim futility boundary
#' has been crossed.
#'
#' @param nsim Number of simulated trials.
#' @param nobs Increasing vector of interim and final sample sizes.
#' @param ptrue True response probability used for simulation.
#' @param p_null Null response-rate threshold.
#' @param phi Response-rate threshold for posterior monitoring. Defaults to
#'   p_null.
#' @param lambda Tuning parameter lambda in lambda * (n / N)^alpha.
#' @param alpha Tuning parameter alpha in lambda * (n / N)^alpha.
#' @param dprior Beta prior parameters. Defaults to c(p_null, 1 - p_null).
#' @param seed Optional random seed. Use NULL to leave the random-number state
#'   unchanged.
#'
#' @return A list containing earlystop, new_rejection, new_accept, meanpts, and
#'   the boundary used for monitoring.
#' @export
#'
#' @examples
#' get_oc_binary(nsim = 1000, nobs = c(20, 40), ptrue = 0.15,
#'               p_null = 0.15, lambda = 0.8, alpha = 0.5)
get_oc_binary <- function(nsim = 10000, nobs, ptrue = 0.2, p_null = 0.2,
                          phi = p_null, lambda = 0.9, alpha = 1,
                          dprior = c(p_null, 1 - p_null), seed = 1024) {
  nobs <- validate_nobs(nobs)
  validate_probability(ptrue, "ptrue")
  validate_strict_probability(p_null, "p_null")
  validate_probability(phi, "phi")
  validate_probability(lambda, "lambda")
  if (!is.numeric(alpha) || length(alpha) != 1L || is.na(alpha) || alpha < 0) {
    stop("alpha must be a single non-negative numeric value.", call. = FALSE)
  }
  validate_prior(dprior)
  if (!is.numeric(nsim) || length(nsim) != 1L || is.na(nsim) || nsim <= 0 || nsim != floor(nsim)) {
    stop("nsim must be a positive integer.", call. = FALSE)
  }
  nsim <- as.integer(nsim)

  if (!is.null(seed)) {
    set.seed(seed)
  }

  boundary <- stopping_boundary_binary(
    nobs = nobs,
    lambda = lambda,
    alpha = alpha,
    p_null = p_null,
    dprior = dprior,
    phi = phi,
    contrast = as.matrix(1)
  )
  stopbound <- boundary$stop_if_responses_leq

  increment_sizes <- c(nobs[1], diff(nobs))
  nlooks <- length(nobs)
  incremental_responses <- matrix(0L, nrow = nsim, ncol = nlooks)
  for (j in seq_len(nlooks)) {
    incremental_responses[, j] <- stats::rbinom(nsim, size = increment_sizes[j], prob = ptrue)
  }
  cumulative_responses <- incremental_responses
  if (nlooks > 1L) {
    for (j in 2:nlooks) {
      cumulative_responses[, j] <- cumulative_responses[, j - 1L] + incremental_responses[, j]
    }
  }

  early_stop <- logical(nsim)
  accept_new_treatment <- logical(nsim)
  sample_size_used <- integer(nsim)

  for (r in seq_len(nsim)) {
    sample_size_used[r] <- nobs[nlooks]
    for (j in seq_len(nlooks)) {
      if (cumulative_responses[r, j] <= stopbound[j]) {
        accept_new_treatment[r] <- FALSE
        sample_size_used[r] <- nobs[j]
        if (j < nlooks) {
          early_stop[r] <- TRUE
        }
        break
      }
      if (j == nlooks) {
        accept_new_treatment[r] <- TRUE
      }
    }
  }

  structure(
    list(
      earlystop = mean(early_stop),
      new_rejection = mean(!accept_new_treatment),
      new_accept = mean(accept_new_treatment),
      meanpts = mean(sample_size_used),
      boundary = boundary
    ),
    class = "bop2_oc_binary"
  )
}

#' Original binary operating-characteristic function name
#'
#' Compatibility wrapper for the original function name in the attached R source
#' code. The argument names b and pow correspond to lambda and alpha.
#'
#' @param nsim Number of simulated trials.
#' @param dprior Beta prior parameters.
#' @param contrast Binary response contrast. Only as.matrix(1) is currently
#'   supported by this binary wrapper.
#' @param nobs Increasing vector of interim and final sample sizes.
#' @param b Lambda tuning parameter.
#' @param pow Alpha tuning parameter.
#' @param ptrue True response probability.
#' @param phi Null response-rate threshold.
#' @param seed Optional random seed.
#'
#' @return A list with earlystop, new_rejection, new_accept, and meanpts, matching
#'   the original source-code output names.
#' @export
#'
#' @examples
#' getoc.bi(nsim = 1000, nobs = c(20, 40), dprior = c(0.15, 0.85),
#'          b = 0.8, pow = 0.5, ptrue = 0.30, phi = 0.15)
getoc.bi <- function(nsim = 10000, dprior = c(0.2, 0.8), contrast = as.matrix(1),
                     nobs, b = 0.9, pow = 1, ptrue = 0.2, phi = 0.2,
                     seed = 1024) {
  contrast <- as_contrast_matrix(contrast)
  if (!identical(dim(contrast), c(1L, 1L)) || contrast[1, 1] != 1) {
    stop("getoc.bi currently supports the binary response contrast as.matrix(1).", call. = FALSE)
  }
  out <- get_oc_binary(
    nsim = nsim,
    nobs = nobs,
    ptrue = ptrue,
    p_null = phi,
    phi = phi,
    lambda = b,
    alpha = pow,
    dprior = dprior,
    seed = seed
  )
  out[c("earlystop", "new_rejection", "new_accept", "meanpts")]
}

# bop2

`bop2` is a compact R package built from the attached BOP2 R source code for the binary endpoint setting. It supports the standard binary phase II use case where the endpoint is response / no response.

The package implements three practical tasks:

1. Calculate binary BOP2 stopping boundaries.
2. Simulate operating characteristics, including type I error, power, probability of early termination, and average sample size.
3. Search over lambda and alpha to find a design that controls type I error and maximizes simulated power.

The source methodology is Zhou, Lee, and Yuan (2017), *BOP2: Bayesian optimal design for phase II clinical trials with simple and complex endpoints*, *Statistics in Medicine*, 36(21), 3302--3314, doi:10.1002/sim.7338.

## Installation

From the source package tarball:

```r
install.packages("bop2_0.1.0.tar.gz", repos = NULL, type = "source")
library(bop2)
```

Or from the unzipped package folder:

```r
install.packages("path/to/bop2", repos = NULL, type = "source")
library(bop2)
```

## Step-by-step example: binary response endpoint

Suppose a single-arm phase II trial monitors objective response. The null response rate is 15%, the alternative response rate is 30%, and the trial will look after 20 and 40 patients. The design target is to keep the one-sided type I error at or below 10%.

### Step 1. Define the design inputs

```r
library(bop2)

nobs <- c(20, 40)       # interim look at 20, final analysis at 40
p_null <- 0.15          # response rate under H0
p_alt <- 0.30           # response rate under H1
target_type1 <- 0.10    # maximum tolerated type I error

lambda_grid <- seq(0.70, 0.90, by = 0.01)
alpha_grid <- seq(0, 1, by = 0.01)
```

### Step 2. Search for lambda and alpha

```r
design <- search_binary_design(
  nobs = nobs,
  p_null = p_null,
  p_alt = p_alt,
  target_type1 = target_type1,
  nsim = 10000,
  lambda_grid = lambda_grid,
  alpha_grid = alpha_grid,
  seed = 1024
)

design
```

The printed object reports the selected `lambda`, selected `alpha`, simulated type I error, simulated power, probability of early termination under the null and alternative, and mean sample size.

### Step 3. Extract the stopping boundary

```r
design$boundary
```

Interpretation: at each look, stop for futility if the cumulative number of responses is less than or equal to `stop_if_responses_leq`. Otherwise, continue to the next look. At the final look, declare the treatment promising only if the cumulative number of responses is greater than the final boundary.

### Step 4. Recalculate operating characteristics at selected response rates

```r
oc_null <- get_oc_binary(
  nsim = 10000,
  nobs = nobs,
  ptrue = p_null,
  p_null = p_null,
  lambda = design$lambda,
  alpha = design$alpha,
  seed = 1024
)

oc_alt <- get_oc_binary(
  nsim = 10000,
  nobs = nobs,
  ptrue = p_alt,
  p_null = p_null,
  lambda = design$lambda,
  alpha = design$alpha,
  seed = 1025
)

oc_null[c("earlystop", "new_accept", "meanpts")]
oc_alt[c("earlystop", "new_accept", "meanpts")]
```

Here `new_accept` is the probability of declaring the treatment promising. Under `p_null`, it estimates the type I error; under `p_alt`, it estimates power.

### Step 5. Use the original function names, if desired

The package keeps the two function names from the attached source code:

```r
maxresp(cutoff = 0.85, dprior = c(p_null, 1 - p_null),
        ntr = 20, phi = p_null, contrast = as.matrix(1))

getoc.bi(nsim = 10000, dprior = c(p_null, 1 - p_null),
         nobs = nobs, b = design$lambda, pow = design$alpha,
         ptrue = p_alt, phi = p_null)
```

## Main functions

- `maxresp()` — original source-code-style response boundary calculator.
- `getoc.bi()` — original source-code-style binary operating-characteristic simulator.
- `stopping_boundary_binary()` — user-friendly boundary table.
- `get_oc_binary()` — user-friendly operating-characteristic simulator.
- `search_binary_design()` — grid search for a type-I-error-controlled, power-maximizing binary BOP2 design.

## Notes

This package currently implements the binary endpoint source code supplied with the request. The BOP2 paper also covers ordinal, nested, co-primary, and efficacy/toxicity endpoint structures; those extensions would require additional multinomial monitoring functions beyond the attached binary R code.

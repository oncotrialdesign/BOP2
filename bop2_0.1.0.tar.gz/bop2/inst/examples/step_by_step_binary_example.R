# Step-by-step BOP2 binary endpoint example
# Scenario: phase II trial with objective response as a binary endpoint.
# H0: response rate = 0.15; H1: response rate = 0.30.
# Interim analysis after 20 patients; final analysis after 40 patients.

library(bop2)

# 1. Define design assumptions
nobs <- c(20, 40)
p_null <- 0.15
p_alt <- 0.30
target_type1 <- 0.10

# 2. Define the grid for the BOP2 posterior cutoff
lambda_grid <- seq(0.70, 0.90, by = 0.01)
alpha_grid <- seq(0, 1, by = 0.01)

# 3. Search for lambda and alpha that control type I error and maximize power
# Increase nsim for protocol-quality work; 10000 is a typical starting point.
design <- search_binary_design(
  nobs = nobs,
  p_null = p_null,
  p_alt = p_alt,
  target_type1 = target_type1,
  nsim = 10000,
  lambda_grid = lambda_grid,
  alpha_grid = alpha_grid,
  seed = 1024
)

print(design)

# 4. Extract the stopping boundaries
# Rule: stop if cumulative responses <= stop_if_responses_leq.
boundary <- design$boundary
print(boundary)

# 5. Confirm operating characteristics under the null and alternative
oc_null <- get_oc_binary(
  nsim = 10000,
  nobs = nobs,
  ptrue = p_null,
  p_null = p_null,
  lambda = design$lambda,
  alpha = design$alpha,
  seed = 1024
)

oc_alt <- get_oc_binary(
  nsim = 10000,
  nobs = nobs,
  ptrue = p_alt,
  p_null = p_null,
  lambda = design$lambda,
  alpha = design$alpha,
  seed = 1025
)

print(oc_null[c("earlystop", "new_accept", "meanpts")])
print(oc_alt[c("earlystop", "new_accept", "meanpts")])

# 6. Optional: use source-code-compatible names
legacy_oc <- getoc.bi(
  nsim = 10000,
  dprior = c(p_null, 1 - p_null),
  nobs = nobs,
  b = design$lambda,
  pow = design$alpha,
  ptrue = p_alt,
  phi = p_null
)
print(legacy_oc)

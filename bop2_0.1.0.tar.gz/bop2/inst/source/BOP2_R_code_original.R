##########################################################################
###########  BOP2 design: function arguments are explained in a binary setting
##########################################################################


###################
#### Functions ####
###################

maxresp <- function(cutoff,dprior,ntr,phi,contrast)
{ ## cutoff: posterior cutoff: lambda*(n/nmax)^alpha
  ## dprior: vector of beta prior parameters for binary data
  ## ntr: current sample size
  ## phi: null response rate in calculating posterior probability P(p > phi) 
  ## contrast: = as.matrix(1) for binary response
  ncut=NULL
  for (i in 1:length(phi))
  {ncut <- c(ncut,max(which(1-pbeta(phi[i],
                                    0:ntr+sum(dprior[which(contrast[i,]==1)]),
                                    ntr:0+sum(dprior)-sum(dprior[which(contrast[i,]==1)]))
                            <cutoff))-1)}
  return (ncut) 
}

getoc.bi <- function(nsim=10000,dprior=c(0.2,0.8),contrast=as.matrix(1),nobs,
                     b=0.9,pow=1,ptrue=0.2,phi=0.2)
{ ## nsim: MC replicates
  ## dprior: vector of beta prior parameters for binary data
  ## contrast: = as.matrix(1) for binary response
  ## nobs: interim sample sizes, e.g. c(10, 25, 40) means two interim looks at 10 and 25 and the final at 40
  ## b: lambda in lambda*(n/nmax)^alpha
  ## pow: alpha in lambda*(n/nmax)^alpha
  ## ptrue: true response rate
  ## phi: null response rate in calculating posterior probability P(p > phi) 
  
  nmax=max(nobs)
  
  set.seed(1024)
  stopbound = NULL
  for (n in nobs)
  {
    stopbound = cbind(stopbound,maxresp(cutoff=b*(n/nmax)^pow,dprior=dprior,contrast=contrast,ntr=n,phi=phi))
  }
  
  resp.list = list()
  resp.list[[1]] <- rbinom(nsim,size=nobs[1],prob=ptrue)
  for (j in 2:length(nobs))
  {
    resp.list[[j]] <- rbinom(nsim,size=nobs[j]-nobs[j-1],prob=ptrue)
  }
  
  earlystop=rej=accept=pts=0
  for (r in 1:nsim)
  {
    abort = 0
    k = 1
    resp = resp.list[[1]][r]
    while(abort == 0)
    {
      if (resp>stopbound[k])
      {resp = resp + resp.list[[k+1]][r]; k = k+1} 
      else {abort = 1}
      if (k==length(stopbound)) break
    }
    if (abort==1) 
    {earlystop = earlystop + 1; rej = rej + 1;}
    else {
      if (resp>stopbound[k]) accept=accept+1
      else rej=rej+1 
    }
    pts <- pts+nobs[k]
  }
  list(earlystop=earlystop/nsim,new_rejection=rej/nsim,new_accept=accept/nsim,meanpts=pts/nsim)
}


###########################
#### Regular searching ####
###########################
err1 = 0.1 ## Type I error
nobs.seq = c(20, 40) ## interim sample size
cut.seq = seq(0.7,0.9,by=0.01) ## range for lambda
power.seq = seq(0,1,by=0.01) ## range for alpha
p.n = 0.15 ## null hypothesis
p.a = 0.3 ## null hypothesis
oc.mat.binary = c() ## output all solutions satisfying the type I error constraint
cut.start = 1

for (j in 1:length(cut.seq))
{
  for (k in cut.start:length(power.seq))
  { #cat("cutoff & power:",c(cut.seq[j],power.seq[k]),"\n")
    temp1=getoc.bi(nobs=nobs.seq,dprior=c(p.n,1-p.n),b=cut.seq[j],pow=power.seq[k],ptrue=p.n,phi=p.n)
    
    if (temp1$new_accept>err1) break;
    temp2=getoc.bi(nobs=nobs.seq,dprior=c(p.n,1-p.n),b=cut.seq[j],pow=power.seq[k],ptrue=p.a,phi=p.n)
    oc.mat.binary <- rbind(oc.mat.binary,c(cut.seq[j],power.seq[k],temp1$new_accept,temp2$new_accept))
  } 
  cut.start = k
  if(cut.start == length(power.seq)) break
}
colnames(oc.mat.binary) <- c("lambda", "alpha", "error", "power")
## first column is lambda; second column is alpha; third column is type I error; fourth column is power
lambda <- oc.mat.binary[which.max(oc.mat.binary[,4]), 1]
alpha <- oc.mat.binary[which.max(oc.mat.binary[,4]), 2]

## Stopping boundaries
stopbound = NULL
for (n in nobs.seq)
{
  stopbound = cbind(stopbound,maxresp(cutoff=lambda*(n/max(nobs.seq))^alpha,
                                      dprior=c(p.n,1-p.n),contrast=as.matrix(1),
                                      ntr=n,phi=p.n))
}
stopbound

### OCs
phi <- 0.15
getoc.bi(nsim = 10000, nobs=nobs.seq, dprior=c(p.n,1-p.n), b=lambda, pow=alpha, ptrue=phi,phi=p.n)
phi <- 0.3
getoc.bi(nsim = 10000, nobs=nobs.seq, dprior=c(p.n,1-p.n), b=lambda, pow=alpha, ptrue=phi,phi=p.n)
